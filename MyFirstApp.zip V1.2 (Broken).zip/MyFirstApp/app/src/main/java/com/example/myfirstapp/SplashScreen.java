package com.example.myfirstapp;

import android.app.Activity;

public class SplashScreen extends Activity {
}
